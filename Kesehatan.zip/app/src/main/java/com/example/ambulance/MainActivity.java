package com.example.ambulance;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //Deklarasi variable
    SQLiteDatabase myDB = null;
    String TableName = "kesehatan";
    String Data = "";
    TextView dtKesehatan;
    Button bSimpan, bEdit, bHapus;
    EditText tnoreg, tNama, tAlamat, tTmp, tTgl, ttelp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dtKesehatan = (TextView)findViewById(R.id.txtData);
        bSimpan = (Button)findViewById(R.id.btnSimpan);
        bEdit = (Button)findViewById(R.id.btnEdit);
        bHapus = (Button)findViewById(R.id.btnHapus);
        tnoreg = (EditText)findViewById(R.id.txtNoreg);
        tNama = (EditText)findViewById(R.id.txtNama);
        tAlamat = (EditText)findViewById(R.id.txtAlamat);
        tTmp = (EditText)findViewById(R.id.txtTmp);
        tTgl = (EditText)findViewById(R.id.txtTgl);
        ttelp = (EditText)findViewById(R.id.txtTelp);
        createDB();
        tampilData();
        bSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                simpan();
            }
        });
        bEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit();
            }
        });
        bHapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hapus();
            }
        });
    }
    //Method Clear TextField
    public void clearField(){
        tnoreg.setText("");
        tNama.setText("");
        tAlamat.setText("");
        tTmp.setText("");
        tTgl.setText("");
        ttelp.setText("");
    }
    //Buat Method Create Database
    public void createDB(){
        try{
            myDB = this.openOrCreateDatabase("DBKESEHATAN",MODE_PRIVATE,null);
            myDB.execSQL("CREATE TABLE IF NOT EXISTS " +
                            TableName + "(NO_REG VARCHAR PRIMARY KEY, NAMA VARCHAR, ALAMAT VARCHAR, TMP VARCHAR, TGL VARCHAR, TELP VARCHAR);");
        }catch (Exception e){
            //Log.e("Error", "Error", e);
        }
    }
    //Buat Method Tampilkan Data
    public void tampilData(){
        try{
            Data = "";
            clearField();
            Cursor c = myDB.rawQuery("Select * From " + TableName, null);
            int col1 = c.getColumnIndex("NO_REG");
            int col2 = c.getColumnIndex("NAMA");
            int col3 = c.getColumnIndex("ALAMAT");
            int col4 = c.getColumnIndex("TMP");
            int col5 = c.getColumnIndex("TGL");
            int col6 = c.getColumnIndex("TELP");
            c.moveToFirst();
            if (c!= null){
                do{
                    String no_reg = c.getString(col1);
                    String namapemesan = c.getString(col2);
                    String almt = c.getString(col3);
                    String tmp = c.getString(col4);
                    String tgl = c.getString(col5);
                    String telp = c.getString(col6);
                    Data = Data +"No. Reg : " + no_reg +" |"+ "Nama : " + namapemesan+" |"+ " Alamat : " + almt + " |"+" Tempat Lahir : " + tmp + " |"+" Tanggal Lahir : " + tgl +  " |"+" Telepon : " + telp + "\n";
                }
                while (c.moveToNext());
            }
            dtKesehatan.setText(Data);
        }catch (Exception e){
            dtKesehatan.setText(Data);
        }
    }
    //Method Simpan Data
    public void simpan(){
        myDB.execSQL("Insert Into " + TableName + " Values('" + tnoreg.getText() +
                "','" + tNama.getText() + "','" + tAlamat.getText() + "','" + tTmp.getText() + "','" + tTgl.getText() + "','" + ttelp.getText() + "');");
        tampilData();
    }
    //Method Edit
    public void edit(){
        myDB.execSQL("Update " + TableName + " Set NAMA = '"+ tNama.getText() +"', ALAMAT = '"+ tAlamat.getText() +"', TMP = '"+ tTmp.getText() +"', TGL = '"+ tTgl.getText() +"', TELP = '"+ ttelp.getText() +"' Where NO_REG = '"+ tnoreg.getText() +"';");
        tampilData();
    }
    //Method Hapus
    public void hapus(){
        myDB.execSQL("Delete From " + TableName + " Where NO_REG = '" + tnoreg.getText() +
                "';");
        tampilData();
    }
}


